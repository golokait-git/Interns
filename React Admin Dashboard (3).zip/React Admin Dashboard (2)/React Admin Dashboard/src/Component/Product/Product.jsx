import React from 'react'

const product = () => {
  return (
    <div>
      
    </div>
  )
}

export default product
