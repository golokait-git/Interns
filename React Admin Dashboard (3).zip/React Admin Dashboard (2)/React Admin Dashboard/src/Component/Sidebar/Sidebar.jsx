// Sidebar.jsx
import React from "react";
import { Link } from "react-router-dom";
import { BsGrid1X2Fill } from "react-icons/bs";
import "./Sidebar.css";

function Sidebar({ openSidebarToggle, OpenSidebar }) {
  return (
    <>
      <aside
        id="sidebar"
        className={openSidebarToggle ? "sidebar-responsive" : ""}
        style={{ backgroundColor: "#739072" }}
      >
        <div
          className="sidebar-title"
          style={{ boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}
        >
          <div className="sidebar-brand">GolokaIT</div>
          <span className="icon close_icon" onClick={OpenSidebar}>
            X
          </span>
        </div>

        <ul
          className="sidebar-list"
          //   style={{ boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}
        >
          <li className="sidebar-list-item">
            <Link to="/" style={{ color: "white" }}>
              <BsGrid1X2Fill className="icon" /> Dashboard
            </Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/sales">👨‍💻 Sales</Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/category">🛠 Category</Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/products">➕ Products</Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/distributers">✔ Distributers</Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/invoice">⏳ Invoice</Link>
          </li>
          <li className="sidebar-list-item">
            <Link to="/profile">⏳ Profile</Link>
          </li>
        </ul>
      </aside>
    </>
  );
}

export default Sidebar;
