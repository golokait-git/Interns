import React from 'react'

const Distributer = () => {
  return (
    <div>
      
    </div>
  )
}

export default Distributer
