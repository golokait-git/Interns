import React, { useState } from 'react';
import {
  BsFillBellFill, BsFillEnvelopeFill, BsPersonCircle, BsSearch, BsJustify, BsX
} from 'react-icons/bs';
import { Link } from 'react-router-dom';
import './Header.css'

function Header({ OpenSidebar }) {
  const [isHovered, setIsHovered] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = () => {
    // Handle the search action here, for example, redirecting to a search results page
    console.log('Searching for:', searchQuery);
  };

  const clearSearch = () => {
    setSearchQuery('');
  };

  return (
    <header className='header'>
      <div className='menu-icon'>
        <BsJustify className='icon' onClick={OpenSidebar} />
      </div>
      <div className='header-left' style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '1' }}>
        {/* Render search bar and search button conditionally */}
        {/* <div >
          <input
            type="text"
            className="search-bar"
            placeholder="Search..."
            style={{ 
              padding: '5px 10px', 
              border: '1px solid #ccc', 
              borderRadius: '20px', 
              marginRight: '10px',
            }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          /> */}
          {/* {searchQuery && (
            <BsX className='icon' onClick={clearSearch} style={{ cursor: 'pointer' }} />
          )} */}
          {/* <BsSearch className='icon' onClick={handleSearch} style={{ cursor: 'pointer' }} />
        </div> */}
      </div>
      <div className='header-right'>
        <Link to='#'>
          <BsFillBellFill className='icon'/>
        </Link>
        {/* <Link to='#'>
          <BsFillEnvelopeFill className='icon'/>
        </Link> */}
        <Link to=''>
          <BsPersonCircle className='icon'/>
        </Link>
      </div>
    </header>
  );
}

export default Header;
