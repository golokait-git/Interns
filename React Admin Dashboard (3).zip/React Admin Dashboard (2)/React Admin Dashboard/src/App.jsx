import React, { useState } from "react";
import "./App.css";
import Header from "./Component/Header/Header";
import Sidebar from "./Component/Sidebar/Sidebar";
import Home from "./Component/Home/Home";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Sales from "./Component/Sales/Sales";
import Category from './Component/Category/Category';
import Distributer from './Component/Distributer/Distributer';
import Product from './Component/Product/Product';
import Profile from './Component/Profile/Profile';
import Invoice from './Component/Invoice/Invoice';

function App() {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false);

  const OpenSidebar = () => {
    setOpenSidebarToggle(!openSidebarToggle);
  };

  return (
    <div className="grid-container">
      <BrowserRouter>
        <Header OpenSidebar={OpenSidebar} />
        <Sidebar
          openSidebarToggle={openSidebarToggle}
          OpenSidebar={OpenSidebar}
        />
        <Routes>
          {/* Home route shown in "/" */}
          <Route path="/" element={<Home />} />
          {/* Sidebar routes */}
          <Route path="/sales" element={<Sales />} />
          <Route path="/category" element={<Category />} />
          <Route path="/products" element={<Product />} />
          <Route path="/distributers" element={<Distributer />} />
          <Route path="/invoice" element={<Invoice />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
