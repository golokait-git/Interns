import { useState } from "react";
import './Category.css'
const Category = () => {
  // Dummy data
  const dummyData = [
    {
      distributerName: "ABC Distributors",
      email: "abc@example.com",
      phone: "123-456-7890",
      totalSpend: "$2000",
      numOfTransactions: 20,
      lastTransaction: "2024-02-19",
    },
    {
      distributerName: "DEF Distributors",
      email: "def@example.com",
      phone: "456-789-0123",
      totalSpend: "$1800",
      numOfTransactions: 18,
      lastTransaction: "2024-02-20",
    },
    {
      distributerName: "GHI Distributors",
      email: "ghi@example.com",
      phone: "789-012-3456",
      totalSpend: "$1700",
      numOfTransactions: 17,
      lastTransaction: "2024-02-17",
    },
    {
      distributerName: "JKL Distributors",
      email: "jkl@example.com",
      phone: "012-345-6789",
      totalSpend: "$1600",
      numOfTransactions: 16,
      lastTransaction: "2024-02-16",
    },
    {
      distributerName: "MNO Distributors",
      email: "mno@example.com",
      phone: "234-567-8901",
      totalSpend: "$1400",
      numOfTransactions: 14,
      lastTransaction: "2024-02-15",
    },
    {
      distributerName: "PQR Distributors",
      email: "pqr@example.com",
      phone: "567-890-1234",
      totalSpend: "$1300",
      numOfTransactions: 13,
      lastTransaction: "2024-02-14",
    },
    {
      distributerName: "STU Distributors",
      email: "stu@example.com",
      phone: "890-123-4567",
      totalSpend: "$1200",
      numOfTransactions: 12,
      lastTransaction: "2024-02-13",
    },
    {
      distributerName: "VWX Distributors",
      email: "vwx@example.com",
      phone: "901-234-5678",
      totalSpend: "$1100",
      numOfTransactions: 11,
      lastTransaction: "2024-02-12",
    },
    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
    {
      distributerName: "BCD Distributors",
      email: "bcd@example.com",
      phone: "123-456-7890",
      totalSpend: "$900",
      numOfTransactions: 9,
      lastTransaction: "2024-02-10",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
    {
      distributerName: "ABC Distributors",
      email: "abc@example.com",
      phone: "123-456-7890",
      totalSpend: "$2000",
      numOfTransactions: 20,
      lastTransaction: "2024-02-19",
    },
    {
      distributerName: "DEF Distributors",
      email: "def@example.com",
      phone: "456-789-0123",
      totalSpend: "$1800",
      numOfTransactions: 18,
      lastTransaction: "2024-02-20",
    },
    {
      distributerName: "GHI Distributors",
      email: "ghi@example.com",
      phone: "789-012-3456",
      totalSpend: "$1700",
      numOfTransactions: 17,
      lastTransaction: "2024-02-17",
    },
    {
      distributerName: "JKL Distributors",
      email: "jkl@example.com",
      phone: "012-345-6789",
      totalSpend: "$1600",
      numOfTransactions: 16,
      lastTransaction: "2024-02-16",
    },
    {
      distributerName: "MNO Distributors",
      email: "mno@example.com",
      phone: "234-567-8901",
      totalSpend: "$1400",
      numOfTransactions: 14,
      lastTransaction: "2024-02-15",
    },
    {
      distributerName: "PQR Distributors",
      email: "pqr@example.com",
      phone: "567-890-1234",
      totalSpend: "$1300",
      numOfTransactions: 13,
      lastTransaction: "2024-02-14",
    },
    {
      distributerName: "STU Distributors",
      email: "stu@example.com",
      phone: "890-123-4567",
      totalSpend: "$1200",
      numOfTransactions: 12,
      lastTransaction: "2024-02-13",
    },
    {
      distributerName: "VWX Distributors",
      email: "vwx@example.com",
      phone: "901-234-5678",
      totalSpend: "$1100",
      numOfTransactions: 11,
      lastTransaction: "2024-02-12",
    },
    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
    {
      distributerName: "BCD Distributors",
      email: "bcd@example.com",
      phone: "123-456-7890",
      totalSpend: "$900",
      numOfTransactions: 9,
      lastTransaction: "2024-02-10",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
    {
      distributerName: "ABC Distributors",
      email: "abc@example.com",
      phone: "123-456-7890",
      totalSpend: "$2000",
      numOfTransactions: 20,
      lastTransaction: "2024-02-19",
    },
    {
      distributerName: "DEF Distributors",
      email: "def@example.com",
      phone: "456-789-0123",
      totalSpend: "$1800",
      numOfTransactions: 18,
      lastTransaction: "2024-02-20",
    },
    {
      distributerName: "GHI Distributors",
      email: "ghi@example.com",
      phone: "789-012-3456",
      totalSpend: "$1700",
      numOfTransactions: 17,
      lastTransaction: "2024-02-17",
    },
    {
      distributerName: "JKL Distributors",
      email: "jkl@example.com",
      phone: "012-345-6789",
      totalSpend: "$1600",
      numOfTransactions: 16,
      lastTransaction: "2024-02-16",
    },
    {
      distributerName: "MNO Distributors",
      email: "mno@example.com",
      phone: "234-567-8901",
      totalSpend: "$1400",
      numOfTransactions: 14,
      lastTransaction: "2024-02-15",
    },
    {
      distributerName: "PQR Distributors",
      email: "pqr@example.com",
      phone: "567-890-1234",
      totalSpend: "$1300",
      numOfTransactions: 13,
      lastTransaction: "2024-02-14",
    },
    {
      distributerName: "STU Distributors",
      email: "stu@example.com",
      phone: "890-123-4567",
      totalSpend: "$1200",
      numOfTransactions: 12,
      lastTransaction: "2024-02-13",
    },
    {
      distributerName: "VWX Distributors",
      email: "vwx@example.com",
      phone: "901-234-5678",
      totalSpend: "$1100",
      numOfTransactions: 11,
      lastTransaction: "2024-02-12",
    },
    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
    {
      distributerName: "BCD Distributors",
      email: "bcd@example.com",
      phone: "123-456-7890",
      totalSpend: "$900",
      numOfTransactions: 9,
      lastTransaction: "2024-02-10",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },

    {
      distributerName: "YZA Distributors",
      email: "yza@example.com",
      phone: "012-345-6789",
      totalSpend: "$1000",
      numOfTransactions: 10,
      lastTransaction: "2024-02-11",
    },
  ];
  // State for search query and selected search criteria
  const [searchQuery, setSearchQuery] = useState("");
  const [searchCriteria, setSearchCriteria] = useState("distributerName");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const startIndex = (currentPage - 1) * itemsPerPage; //10
  const endIndex = startIndex + itemsPerPage;

  // Function to handle search query change
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  // Function to handle search criteria change
  const handleCriteriaChange = (e) => {
    setSearchCriteria(e.target.value);
  };

  // Function to filter distributors based on search query and criteria
  const filteredDistributors = dummyData.filter((distributor) => {
    const value = distributor[searchCriteria];
    // Check if the value is a string before applying toLowerCase()
    if (typeof value === "string") {
      return value.toLowerCase().includes(searchQuery.toLowerCase());
    }
    // Return false if the value is not a string
    return false;
  });

  // Function to handle filter button click
  const handleFilterButtonClick = (filterCriteria) => {
    console.log("Filter criteria:", filterCriteria);
  };

  const totalPages = Math.ceil(filteredDistributors.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredDistributors.slice(startIndex, endIndex);
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="main-container px-8 mt-3">
      <div className="table-title" style={{ color: "#9e95a2" }}>
        <h2>CATEGORY</h2>
      </div>
      <div className="filter-buttons-container">
        {/* Buttons for filtering */}
        <button
          className="filter-button"
          onClick={() => handleFilterButtonClick("allCustomers")}
        >
          All Customers
        </button>
        <button
          className="filter-button"
          onClick={() => handleFilterButtonClick("loyalCustomers")}
        >
          Loyal Customers
        </button>
        <button
          className="filter-button"
          onClick={() => handleFilterButtonClick("valuableCustomers")}
        >
          Valuable Customers
        </button>
        <button
          className="filter-button"
          onClick={() => handleFilterButtonClick("newCustomers")}
        >
          New Customers
        </button>
      </div>

      <div className="mt-3">
        {/* Search bar */}
        <input
          type="text"
          placeholder="Search..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="search-bar"
        />
        {/* Dropdown for selecting search criteria */}
        <select
          value={searchCriteria}
          onChange={handleCriteriaChange}
          className="search-dropdown"
        >
          <option value="distributerName">Distributer Name</option>
          <option value="email">Email</option>
          <option value="phone">Phone No.</option>
          <option value="totalSpend">Total Spend</option>
          {/* <option value="numOfTransactions">No. of Transactions</option> */}
          <option value="lastTransaction">Last Transaction</option>
        </select>
        {/*Table*/}
        <div className="table-container" style={{ marginTop: "2%" }}>
          <table className="table">
            <thead className="table-header">
              <tr>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  Distributer Name
                </th>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  Email
                </th>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  Phone No.
                </th>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  Total Spend
                </th>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  No. of Transactions
                </th>
                <th
                  className="table-cell"
                  style={{ backgroundColor: "#D3D3D3" }}
                >
                  Last Transaction
                </th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((data, index) => (
                <tr key={index} className="table-row">
                  <td className="table-cell">{data.distributerName}</td>
                  <td className="table-cell">{data.email}</td>
                  <td className="table-cell">{data.phone}</td>
                  <td className="table-cell">{data.totalSpend}</td>
                  <td className="table-cell">{data.numOfTransactions}</td>
                  <td className="table-cell">{data.lastTransaction}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="pagination_rounded">
          <ul>
            {currentPage === 1 ? null : (
              <li>
                <a
                  href="#"
                  className="prev"
                  onClick={() => setCurrentPage(currentPage - 1)}
                >
                  {" "}
                  <i
                    className="fa fa-angle-left"
                    aria-hidden="true"
                  ></i> Prev{" "}
                </a>
              </li>
            )}
            {Array.from({ length: totalPages }, (_, i) => (
              <li key={i}>
                <a
                  href="#"
                  className={currentPage === i + 1 ? "active" : ""}
                  onClick={() => handlePageChange(i + 1)}
                >
                  {i + 1}
                </a>
              </li>
            ))}
            {currentPage === totalPages ? null : (
              <li>
                <a
                  href="#"
                  className="next"
                  onClick={() => setCurrentPage(currentPage + 1)}
                >
                  {" "}
                  Next <i
                    className="fa fa-angle-right"
                    aria-hidden="true"
                  ></i>{" "}
                </a>
              </li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Category;
