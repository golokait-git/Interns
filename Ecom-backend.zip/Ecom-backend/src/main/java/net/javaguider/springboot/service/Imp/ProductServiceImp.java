//package net.javaguider.springboot.service.Imp;
//import java.util.List;
//import org.springframework.stereotype.Service;
//import net.javaguider.springboot.exception.ResourceNotFoundException;
//import net.javaguider.springboot.model.Product;
//import net.javaguider.springboot.repository.ProductRepository;
//import net.javaguider.springboot.service.ProductService;
//@Service
//public class ProductServiceImp implements ProductService {
//
//	
//	
//	private ProductRepository productRepository;
//	
//	public ProductServiceImp(ProductRepository productRepository) {
//		super();
//		this.productRepository = productRepository;
//	}
//	
//	@Override
//	public Product saveProduct(Product product) {
//		
//		return productRepository.save(product);
//	}
//
//	@Override
//	public List<Product> getAllProducts() {
//		return productRepository.findAll();
//	}
//
//	@Override
//	public Product updateProduct(Product product, Long id) {
//		Product  existingProduct = productRepository.findById(id).orElseThrow(
//				() -> new ResourceNotFoundException("Product","Id",id));
//		existingProduct.setProductName(product.getProductName());
//		existingProduct.setPrice(product.getPrice());
//		existingProduct.setDescription(product.getDescription());
//		existingProduct.setStock(product.getStock());
//		existingProduct.setCategory(product.getCategory());
//		existingProduct.setSubCategory(product.getSubCategory());
//		existingProduct.setImgUrl(product.getImgUrl());
//		
//		
//		//save existing employee in DB
//		productRepository.save(existingProduct);
//		
//		return existingProduct;
//		
//	}
//
//	@Override
//	public void deleteProduct(Long id) {
//		 Product product = productRepository.findById(id).orElseThrow(() ->
//                           new ResourceNotFoundException("Product", "Id", id));
//
//           // Perform the deletion
//            productRepository.delete(product);
//		
//	}
//
//	public Product getProductById(Long id) {
//
//		return productRepository.findById(id).orElseThrow(()-> 
//		new ResourceNotFoundException("product","Id",id));
//	}
//
//
//	
//	
//	
//}
