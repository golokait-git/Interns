package net.javaguider.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguider.springboot.model.User;

public interface UserRepository extends JpaRepository<User,Long>{
	User findByuserId(int userId);
}
