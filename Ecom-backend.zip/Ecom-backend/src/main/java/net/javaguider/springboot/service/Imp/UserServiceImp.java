//package net.javaguider.springboot.service.Imp;
//
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import net.javaguider.springboot.exception.ResourceNotFoundException;
//import net.javaguider.springboot.model.User;
//
//import net.javaguider.springboot.repository.UserRepository;
//import net.javaguider.springboot.service.UserService;
//@Service
//public class UserServiceImp implements UserService {
//
//	
//	private UserRepository userRepository;
//
//    public UserServiceImp(UserRepository userRepository) {
//        super();
//        this.userRepository = userRepository;
//    }
//
//    @Override
//    public User createUser(User user) {
//        return userRepository.save(user);
//    }
//
//	@Override
//	public List<User> getAllUser() {
//		
//		return userRepository.findAll();
//	}
//
//	@Override
//	public User getUserById(Long id) {
//		return userRepository.findById(id).orElseThrow(()-> 
//		new ResourceNotFoundException("category id is not present"));
//	}
//
//}
