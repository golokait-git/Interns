package net.javaguider.springboot.service;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.mapping.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguider.springboot.exception.ResourceNotFoundException;
import net.javaguider.springboot.model.Category;
import net.javaguider.springboot.model.Product;
import net.javaguider.springboot.model.SubCategory;
import net.javaguider.springboot.payload.CategoryDto;
import net.javaguider.springboot.payload.ProductDto;
import net.javaguider.springboot.payload.SubCategoryDto;
import net.javaguider.springboot.repository.CategoryRepository;
import net.javaguider.springboot.repository.ProductRepository;
@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;
	private CategoryRepository catRepo;
	
	
	public ProductService (CategoryRepository catRepo) {
        this.catRepo = catRepo;
    }
	
	
	
	public ProductDto saveProduct(ProductDto product,int catid) {
		 
	    Category cat = this.catRepo.findById(catid).orElseThrow(() -> new ResourceNotFoundException("This Category id not found Catgory "));

	    // ProductDto to product entity
	    Product productEntity = toEntity(product);
	    productEntity.setCategory(cat);

	    // Save the product entity
	    Product savedProduct = this.productRepository.save(productEntity);

	    // Convert the saved product entity to a ProductDto
	    ProductDto dto = toDto(savedProduct);

	    // Return the ProductDto
	    return dto;
	}

	
//get all product
	public List<ProductDto> getAllProducts() {
		//productDto to product
		List <Product> findAll=productRepository.findAll();
		List<ProductDto> findAllDto=findAll.stream().map(product -> this.toDto(product)).collect(Collectors.toList());
		return findAllDto;
	}


	
	//update product
	public ProductDto updateProduct(Long id, ProductDto productDto) {
	    Product existingProduct = productRepository.findById(id)
	            .orElseThrow(() -> new ResourceNotFoundException(+id+"from this product id product not found"));
	    existingProduct.setProductName(productDto.getProductName());
	    existingProduct.setPrice(productDto.getPrice());
	    existingProduct.setDescription(productDto.getDescription());
	    existingProduct.setStock(productDto.getStock());
//	    existingProduct.setCategory(productDto.getCategory());
//	    existingProduct.setSubCategory(productDto.getSubCategory());
	    existingProduct.setImgUrl(productDto.getImgUrl());

	    // Save existing product in the DB
	    Product savedProduct = productRepository.save(existingProduct);

	    return toDto(savedProduct);
	}

	


	//delete product
	public void deleteProduct(Long id) {
		 Product product = productRepository.findById(id).orElseThrow(() ->
                           new ResourceNotFoundException(+id+"from this product id product not found"));

           // Perform the deletion
            productRepository.delete(product);
		
	}

	
	//product get by id
	public ProductDto getProductById(Long id) {

		Product findById = productRepository.findById(id).orElseThrow(()-> 
		new ResourceNotFoundException(+id+"from this product id product not found"));
		
		ProductDto dto = this.toDto(findById);
		return dto;
	}
	
	
	
	//find product by category
	
	public List<ProductDto>findProductByCategory(int catid){
		
		
		
		Category cat=this.catRepo.findById(catid).orElseThrow(() ->
        new ResourceNotFoundException("This id Category not Found"));
		
		List<Product>findByCategory=this.productRepository.findByCategory(cat);
		List<ProductDto> collect =findByCategory.stream().map(product ->toDto(product)).collect(Collectors.toList());
		return collect;
	}

	
	public Product toEntity(ProductDto productDto) {
		
		Product p = new Product();
		p.setProductName(productDto.getProductName());
		p.setId(productDto.getId());
//		p.setCategory(productDto.getCategory());
		p.setDescription(productDto.getDescription());
		p.setImgUrl(productDto.getImgUrl());
		p.setPrice(productDto.getPrice());
		p.setStock(productDto.getStock());
//		p.setSubCategory(productDto.getSubCategory());
		
		
		return p;
		
	}
	
//	
//	
//	public ProductDto toDto(Product Product) {
//		
//		ProductDto pDto = new ProductDto();
//		pDto.setProductName(Product.getProductName());
//		pDto.setId(Product.getId());
////		pDto.setCategory(Product.getCategory());
//		pDto.setDescription(Product.getDescription());
//		pDto.setImgUrl(Product.getImgUrl());
//		pDto.setPrice(Product.getPrice());
//		pDto.setStock(Product.getStock());
////		pDto.setSubCategory(Product.getSubCategory());
//		
//		//change to category to categoryDto
//		CategoryDto catDto = new  CategoryDto();
//		
//	
//		catDto.setCategoryId(Product.getCategory().getCategoryId());
//		catDto.setTitle(Product.getCategory().getTitle());
	
//		catDto.setSubCateDto(Product.getCategory().getSubCategory());
//
//		
//		SubCategoryDto  subDto= new SubCategoryDto();
//	subDto.setSubcateId(Product.getSubCategory().getSubcateId());
//	subDto.setSubcatName(Product.getSubCategory().getSubcatName());
//	subDto.setCategoryDto(Product.getCategory().getSubCategory());
//	
//		
//		//set categoty Dto in productDto
//		pDto.setCategory(catDto);
//		//set subcategoryDto to productDto 
//
//		
//		return pDto;
//		
//	}

	
	public ProductDto toDto(Product product) {
	    ProductDto productDto = new ProductDto();
	    productDto.setProductName(product.getProductName());
	    productDto.setId(product.getId());
	    productDto.setDescription(product.getDescription());
	    productDto.setImgUrl(product.getImgUrl());
	    productDto.setPrice(product.getPrice());
	    productDto.setStock(product.getStock());

	    // Mapping CategoryDto
	    CategoryDto categoryDto = new CategoryDto();
	    categoryDto.setCategoryId(product.getCategory().getCategoryId());
	    categoryDto.setTitle(product.getCategory().getTitle());
	    
//	    // Mapping SubCategoryDto
//	    SubCategoryDto subCategoryDto = new SubCategoryDto();
//	    SubCategory subCategory = product.getSubCategory();
//	    subCategoryDto.setSubcateId(subCategory.getSubcateId());
//	    subCategoryDto.setSubcatName(subCategory.getSubcatName());
//
//	    // Assuming SubCategory has a reference to Category
//	    CategoryDto subCategoryCategoryDto = new CategoryDto();
//	    subCategoryCategoryDto.setCategoryId(subCategory.getCategory().getCategoryId());
//	    subCategoryCategoryDto.setTitle(subCategory.getCategory().getTitle());
//	    subCategoryDto.setCategoryDto(subCategoryCategoryDto);
//
//	    categoryDto.setSubCateDto(subCategoryDto);
//	    productDto.setCategory(categoryDto);
	    
	 // Mapping SubCategoryDto
	    SubCategoryDto subCategoryDto = new SubCategoryDto();
	    SubCategory subCategory = product.getSubCategory();

	    if (subCategory != null) {
	        subCategoryDto.setSubcateId(subCategory.getSubcateId());
	        subCategoryDto.setSubcatName(subCategory.getSubcatName());

	        // Assuming SubCategory has a reference to Category
	        CategoryDto subCategoryCategoryDto = new CategoryDto();
	        subCategoryCategoryDto.setCategoryId(subCategory.getCategory().getCategoryId());
	        subCategoryCategoryDto.setTitle(subCategory.getCategory().getTitle());
	        subCategoryDto.setCategoryDto(subCategoryCategoryDto);
	    }

	    categoryDto.setSubCateDto(subCategoryDto);
	    productDto.setCategory(categoryDto);


	    return productDto;
	}

}
